# La Bonica Café — Web estática (exportación)

## Requisitos
- Node.js 18+ y yarn (`npm install -g yarn`)

## Instalar y probar en local
```
yarn install
yarn start
```
Abre http://localhost:3000

## Compilar para producción (web estática)
```
yarn build
```
La carpeta `build/` resultante contiene la web estática lista para subir a
Vercel, Netlify, GitHub Pages, Cloudflare Pages o cualquier hosting estático.

## Editar contenido del negocio
Todo el contenido (teléfono, dirección, fotografías, reseñas, horarios,
redes sociales y enlaces legales) está centralizado en:
`src/data/business.js`

Las fotografías actuales son marcadores de posición (stock). Sustituye las
URLs en `GALLERY_IMAGES`, `HERO_IMAGE` y `ABOUT_IMAGE` por las fotos reales.

## Nota
Las dependencias `@emergentbase/*` en package.json son opcionales (solo se
usan en modo desarrollo dentro de Emergent y fallan de forma segura si no
están disponibles). Puedes eliminar esas dos líneas de devDependencies si
`yarn install` da problemas fuera de la plataforma.
