import { motion, useReducedMotion } from "framer-motion";

export function Reveal({ children, delay = 0, y = 28, className = "", ...rest }) {
  const reduce = useReducedMotion();
  return (
    <motion.div
      className={className}
      initial={reduce ? false : { opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-70px" }}
      transition={{ duration: 0.75, delay, ease: [0.22, 1, 0.36, 1] }}
      {...rest}
    >
      {children}
    </motion.div>
  );
}

export function ChapterLabel({ number, title }) {
  return (
    <p className="flex items-center gap-3 text-[11px] font-semibold uppercase tracking-[0.28em] text-terracotta">
      <span aria-hidden="true" className="inline-block h-px w-10 bg-terracotta/60" />
      Capítulo {number} — {title}
    </p>
  );
}
