import { Star, MapPin } from "lucide-react";
import { Reveal, ChapterLabel } from "./Reveal";
import { BUSINESS, ABOUT_IMAGE } from "../../data/business";

export default function About() {
  return (
    <section id="nosotros" className="mx-auto max-w-7xl px-4 py-20 sm:px-6 sm:py-28 lg:px-12 lg:py-36">
      <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-20">
        <div>
          <Reveal>
            <ChapterLabel number="01" title="Nosotros" />
          </Reveal>
          <Reveal delay={0.08}>
            <h2 className="mt-6 font-display text-3xl font-medium leading-tight tracking-tight text-ink sm:text-4xl lg:text-5xl text-balance">
              Un rincón para <span className="italic text-terracotta">disfrutar</span>
            </h2>
          </Reveal>
          <Reveal delay={0.16}>
            <p className="mt-6 text-base leading-relaxed text-ink-soft sm:text-lg">
              La Bonica Café es una cafetería en Xaló, en el corazón de la comarca de la
              Marina Alta alicantina, donde el café se sirve con calma y los dulces llegan
              a la mesa hechos como en casa.
            </p>
          </Reveal>
          <Reveal delay={0.24}>
            <p className="mt-4 text-base leading-relaxed text-ink-soft sm:text-lg">
              Quienes nos visitan destacan especialmente dos cosas: el café y los dulces
              caseros. Aquí puedes sentarte, tomar algo dentro del local y dejar que la
              mañana — o la tarde — sepa un poco mejor.
            </p>
          </Reveal>
          <Reveal delay={0.32}>
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <span
                className="inline-flex items-center gap-2 rounded-full border border-line bg-white px-4 py-2 text-sm font-medium text-ink"
                data-testid="about-rating-chip"
              >
                <Star className="h-4 w-4 fill-gold text-gold" aria-hidden="true" />
                {BUSINESS.rating.value}/{BUSINESS.rating.outOf} en {BUSINESS.rating.count} reseñas
              </span>
              <span className="inline-flex items-center gap-2 text-sm text-muted">
                <MapPin className="h-4 w-4 text-terracotta" aria-hidden="true" />
                {BUSINESS.address.street}, {BUSINESS.address.city}
              </span>
            </div>
          </Reveal>
        </div>

        <Reveal delay={0.15} className="relative">
          <div className="relative overflow-hidden rounded-3xl">
            <img
              src={ABOUT_IMAGE}
              alt="Preparación artesanal de café en La Bonica Café"
              loading="lazy"
              className="aspect-[4/5] w-full object-cover transition-transform duration-700 hover:scale-[1.03] sm:aspect-[5/5]"
            />
          </div>
          <div
            className="absolute -bottom-6 -left-4 rounded-2xl bg-ink px-6 py-5 text-cream shadow-xl sm:-left-8"
            data-testid="about-highlight-card"
          >
            <p className="font-display text-2xl italic text-gold">Hecho en casa</p>
            <p className="mt-1 text-sm text-sand/80">Café, dulces y tartas para comer aquí</p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
