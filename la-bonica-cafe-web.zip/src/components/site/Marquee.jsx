import { Coffee } from "lucide-react";

const ITEMS = [
  "Café cuidado",
  "Dulces y tartas caseras",
  "Club sándwich",
  "Para comer aquí",
  "Xaló · Jalón",
  "Ambiente acogedor",
];

export default function Marquee() {
  const row = (ariaHidden) => (
    <div aria-hidden={ariaHidden} className="flex shrink-0 items-center">
      {ITEMS.map((item) => (
        <span key={`${item}-${ariaHidden}`} className="flex items-center">
          <span className="px-6 font-display text-sm uppercase tracking-[0.3em] text-sand/90 sm:text-base">
            {item}
          </span>
          <Coffee className="h-4 w-4 text-gold/80" aria-hidden="true" />
        </span>
      ))}
    </div>
  );

  return (
    <div className="overflow-hidden border-y border-cream/10 bg-ink py-5" data-testid="editorial-marquee">
      <div className="marquee-track flex w-max">
        {row(false)}
        {row(true)}
      </div>
    </div>
  );
}
