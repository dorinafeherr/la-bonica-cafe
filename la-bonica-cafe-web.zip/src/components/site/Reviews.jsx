import { Star, Quote, ArrowUpRight } from "lucide-react";
import { Reveal, ChapterLabel } from "./Reveal";
import { BUSINESS, REVIEWS } from "../../data/business";

export default function Reviews() {
  return (
    <section id="resenas" className="bg-ink text-cream">
      <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 sm:py-28 lg:px-12 lg:py-36">
        <Reveal>
          <p className="flex items-center gap-3 text-[11px] font-semibold uppercase tracking-[0.28em] text-gold">
            <span aria-hidden="true" className="inline-block h-px w-10 bg-gold/60" />
            Capítulo 04 — Reseñas
          </p>
        </Reveal>

        <div className="mt-10 grid gap-12 lg:grid-cols-[1fr_1.6fr] lg:gap-20">
          <div>
            <Reveal delay={0.08}>
              <h2 className="font-display text-3xl font-medium leading-tight tracking-tight sm:text-4xl lg:text-5xl text-balance">
                Lo que dicen <span className="italic text-gold">nuestros clientes</span>
              </h2>
            </Reveal>
            <Reveal delay={0.16}>
              <div
                className="mt-10 inline-flex flex-col rounded-3xl border border-cream/15 bg-cream/5 p-8"
                data-testid="reviews-summary-badge"
              >
                <span className="font-display text-6xl font-medium tracking-tight sm:text-7xl">
                  {BUSINESS.rating.value}
                  <span className="text-2xl text-sand/60">/{BUSINESS.rating.outOf}</span>
                </span>
                <span className="mt-3 flex gap-1" aria-label={`Valoración de ${BUSINESS.rating.value} sobre 5`}>
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-gold text-gold" aria-hidden="true" />
                  ))}
                </span>
                <span className="mt-3 text-sm text-sand/75">{BUSINESS.rating.count} reseñas</span>
              </div>
            </Reveal>
            <Reveal delay={0.24}>
              <a
                href={BUSINESS.maps.reviewsUrl}
                target="_blank"
                rel="noopener noreferrer"
                data-testid="reviews-more-button"
                className="group mt-8 inline-flex items-center gap-2 rounded-full border border-cream/25 px-7 py-3.5 text-sm font-semibold text-cream transition-colors duration-300 hover:border-gold hover:text-gold"
              >
                Ver más reseñas
                <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden="true" />
              </a>
            </Reveal>
          </div>

          <div className="grid content-start gap-5 sm:gap-6">
            {REVIEWS.map((review, i) => (
              <Reveal key={review.quote} delay={0.1 * i}>
                <figure
                  data-testid={`review-card-${i}`}
                  className="rounded-3xl border border-cream/10 bg-cream/[0.06] p-6 transition-colors duration-500 hover:border-gold/40 sm:p-8"
                >
                  <Quote className="h-6 w-6 text-gold/70" aria-hidden="true" />
                  <blockquote className="mt-4 font-display text-lg italic leading-relaxed text-sand sm:text-xl">
                    “{review.quote}”
                  </blockquote>
                  <figcaption className="mt-5 text-xs font-semibold uppercase tracking-[0.2em] text-sand/60">
                    {review.source}
                  </figcaption>
                </figure>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
