import { motion } from "framer-motion";
import { Phone } from "lucide-react";
import { BUSINESS } from "../../data/business";

export default function FloatingCall() {
  return (
    <motion.a
      href={BUSINESS.phone.href}
      data-testid="mobile-floating-call-button"
      aria-label={`Llamar a La Bonica Café: ${BUSINESS.phone.display}`}
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 1.6, duration: 0.5, ease: "easeOut" }}
      className="fixed bottom-5 right-5 z-40 inline-flex items-center gap-2 rounded-full bg-terracotta px-6 py-4 text-sm font-bold text-cream shadow-[0_12px_32px_-8px_rgba(200,109,81,0.7)] transition-colors hover:bg-coffee-dark md:hidden"
    >
      <span className="relative flex h-5 w-5 items-center justify-center">
        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-cream/40 motion-reduce:hidden" aria-hidden="true" />
        <Phone className="relative h-4 w-4" aria-hidden="true" />
      </span>
      Llamar
    </motion.a>
  );
}
