import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Phone, Menu, X } from "lucide-react";
import { BUSINESS, NAV_LINKS } from "../../data/business";

export default function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  const light = !scrolled && !open;

  return (
    <header
      data-testid="site-header"
      className={`fixed inset-x-0 top-0 z-50 transition-[background-color,box-shadow,border-color] duration-500 ${
        scrolled || open
          ? "border-b border-line/70 bg-cream/90 shadow-[0_8px_30px_rgba(44,34,30,0.06)] backdrop-blur-xl"
          : "border-b border-transparent bg-transparent"
      }`}
    >
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-12">
        <a
          href="#inicio"
          data-testid="header-logo"
          className={`font-display text-xl font-medium tracking-tight transition-colors duration-500 sm:text-2xl ${light ? "text-cream" : "text-ink"}`}
          aria-label="La Bonica Café — ir al inicio"
          onClick={() => setOpen(false)}
        >
          La Bonica <span className={`italic ${light ? "text-gold" : "text-terracotta"}`}>Café</span>
        </a>

        <nav aria-label="Navegación principal" className="hidden items-center gap-8 lg:flex">
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              data-testid={link.testid}
              className={`text-sm font-medium transition-colors duration-300 ${
                light ? "text-sand/90 hover:text-gold" : "text-ink-soft hover:text-terracotta"
              }`}
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <a
            href={BUSINESS.phone.href}
            data-testid="header-call-button"
            className={`hidden items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold transition-colors duration-300 sm:inline-flex ${
              light ? "bg-cream text-ink hover:bg-gold" : "bg-ink text-cream hover:bg-terracotta"
            }`}
          >
            <Phone className="h-4 w-4" aria-hidden="true" />
            Llamar
          </a>
          <button
            type="button"
            data-testid="mobile-menu-button"
            aria-label={open ? "Cerrar menú" : "Abrir menú"}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
            className={`inline-flex h-11 w-11 items-center justify-center rounded-full border transition-colors duration-500 ${
              light ? "border-cream/30 bg-cream/10 text-cream" : "border-line bg-cream/80 text-ink"
            } lg:hidden`}
          >
            {open ? <X className="h-5 w-5" aria-hidden="true" /> : <Menu className="h-5 w-5" aria-hidden="true" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.nav
            aria-label="Navegación móvil"
            data-testid="mobile-menu"
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
            className="border-t border-line/60 bg-cream/95 backdrop-blur-xl lg:hidden"
          >
            <ul className="space-y-1 px-4 py-6 sm:px-6">
              {NAV_LINKS.map((link, i) => (
                <motion.li
                  key={link.href}
                  initial={{ opacity: 0, x: -14 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.05 * i, duration: 0.3 }}
                >
                  <a
                    href={link.href}
                    data-testid={`mobile-${link.testid}`}
                    onClick={() => setOpen(false)}
                    className="block rounded-xl px-4 py-3.5 font-display text-2xl text-ink transition-colors hover:bg-sand/60 hover:text-terracotta"
                  >
                    {link.label}
                  </a>
                </motion.li>
              ))}
              <li className="pt-4">
                <a
                  href={BUSINESS.phone.href}
                  data-testid="mobile-menu-call-button"
                  className="flex items-center justify-center gap-2 rounded-full bg-ink px-6 py-4 text-base font-semibold text-cream transition-colors hover:bg-terracotta"
                >
                  <Phone className="h-5 w-5" aria-hidden="true" />
                  Llamar · {BUSINESS.phone.display}
                </a>
              </li>
            </ul>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}
