import { useCallback, useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, ChevronLeft, ChevronRight, Images } from "lucide-react";
import { Reveal, ChapterLabel } from "./Reveal";
import { GALLERY_IMAGES } from "../../data/business";

const INITIAL_COUNT = 6;

export default function Gallery() {
  const [showAll, setShowAll] = useState(false);
  const [active, setActive] = useState(null);
  const visible = showAll ? GALLERY_IMAGES : GALLERY_IMAGES.slice(0, INITIAL_COUNT);

  const close = useCallback(() => setActive(null), []);
  const step = useCallback(
    (dir) => setActive((i) => (i === null ? null : (i + dir + GALLERY_IMAGES.length) % GALLERY_IMAGES.length)),
    []
  );

  useEffect(() => {
    if (active === null) return;
    const onKey = (e) => {
      if (e.key === "Escape") close();
      if (e.key === "ArrowRight") step(1);
      if (e.key === "ArrowLeft") step(-1);
    };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [active, close, step]);

  return (
    <section id="galeria" className="mx-auto max-w-7xl px-4 py-20 sm:px-6 sm:py-28 lg:px-12 lg:py-36">
      <Reveal>
        <ChapterLabel number="03" title="Galería" />
      </Reveal>
      <div className="mt-6 flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
        <Reveal delay={0.08}>
          <h2 className="font-display text-3xl font-medium leading-tight tracking-tight text-ink sm:text-4xl lg:text-5xl text-balance">
            Momentos en <span className="italic text-terracotta">La Bonica</span>
          </h2>
        </Reveal>
        <Reveal delay={0.16}>
          <p className="max-w-md text-sm leading-relaxed text-muted sm:text-base">
            Café, dulces, tartas y el ambiente de la casa. Toca cualquier foto para verla en grande.
          </p>
        </Reveal>
      </div>

      <div className="mt-14 columns-2 gap-4 sm:gap-5 lg:columns-3" data-testid="gallery-grid">
        {visible.map((img, i) => (
          <Reveal key={img.src} delay={0.05 * (i % 3)} className="mb-4 break-inside-avoid sm:mb-5">
            <button
              type="button"
              data-testid={`gallery-item-${i}`}
              onClick={() => setActive(GALLERY_IMAGES.indexOf(img))}
              className="group relative block w-full overflow-hidden rounded-2xl focus-visible:outline-terracotta"
              aria-label={`Ampliar foto: ${img.alt}`}
            >
              <img
                src={img.src}
                alt={img.alt}
                loading="lazy"
                className="w-full object-cover transition-transform duration-700 group-hover:scale-[1.04]"
              />
              <span className="absolute inset-0 bg-ink/0 transition-colors duration-500 group-hover:bg-ink/20" aria-hidden="true" />
            </button>
          </Reveal>
        ))}
      </div>

      {!showAll && GALLERY_IMAGES.length > INITIAL_COUNT && (
        <Reveal delay={0.1} className="mt-10 text-center">
          <button
            type="button"
            data-testid="gallery-show-all-button"
            onClick={() => setShowAll(true)}
            className="inline-flex items-center gap-2 rounded-full bg-ink px-8 py-4 text-sm font-semibold text-cream transition-colors duration-300 hover:bg-terracotta"
          >
            <Images className="h-4 w-4" aria-hidden="true" />
            Ver todas las fotos
          </button>
        </Reveal>
      )}

      <AnimatePresence>
        {active !== null && (
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label="Visor de fotografías"
            data-testid="gallery-lightbox"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 z-[70] flex items-center justify-center bg-ink/95 p-4 backdrop-blur-sm"
            onClick={close}
          >
            <button
              type="button"
              data-testid="lightbox-close-button"
              onClick={close}
              aria-label="Cerrar visor"
              className="absolute right-4 top-4 z-10 inline-flex h-12 w-12 items-center justify-center rounded-full border border-cream/25 text-cream transition-colors hover:bg-cream/10"
            >
              <X className="h-5 w-5" aria-hidden="true" />
            </button>
            <button
              type="button"
              data-testid="lightbox-prev-button"
              onClick={(e) => { e.stopPropagation(); step(-1); }}
              aria-label="Foto anterior"
              className="absolute left-3 top-1/2 z-10 inline-flex h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full border border-cream/25 text-cream transition-colors hover:bg-cream/10 sm:left-6"
            >
              <ChevronLeft className="h-6 w-6" aria-hidden="true" />
            </button>
            <button
              type="button"
              data-testid="lightbox-next-button"
              onClick={(e) => { e.stopPropagation(); step(1); }}
              aria-label="Foto siguiente"
              className="absolute right-3 top-1/2 z-10 inline-flex h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full border border-cream/25 text-cream transition-colors hover:bg-cream/10 sm:right-6"
            >
              <ChevronRight className="h-6 w-6" aria-hidden="true" />
            </button>

            <motion.figure
              key={active}
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className="max-h-full max-w-4xl"
              onClick={(e) => e.stopPropagation()}
            >
              <img
                src={GALLERY_IMAGES[active].src}
                alt={GALLERY_IMAGES[active].alt}
                className="max-h-[76vh] w-auto max-w-full rounded-2xl object-contain"
              />
              <figcaption className="mt-4 flex items-center justify-between gap-4 text-sm text-sand/85">
                <span data-testid="lightbox-caption">{GALLERY_IMAGES[active].alt}</span>
                <span data-testid="lightbox-counter" className="shrink-0 tabular-nums">
                  {active + 1} / {GALLERY_IMAGES.length}
                </span>
              </figcaption>
            </motion.figure>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
