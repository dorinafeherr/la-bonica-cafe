import { useRef } from "react";
import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { MapPin, Star, ArrowDown } from "lucide-react";
import { BUSINESS, HERO_IMAGE } from "../../data/business";

const lineVariants = {
  hidden: { y: "115%" },
  visible: (i) => ({
    y: "0%",
    transition: { delay: 0.25 + i * 0.14, duration: 0.9, ease: [0.22, 1, 0.36, 1] },
  }),
};

export default function Hero() {
  const reduce = useReducedMotion();
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const bgY = useTransform(scrollYProgress, [0, 1], ["0%", reduce ? "0%" : "22%"]);

  return (
    <section id="inicio" ref={ref} className="relative flex min-h-[100svh] items-end overflow-hidden bg-ink">
      <motion.div style={{ y: bgY }} className="absolute inset-0 scale-110" aria-hidden="true">
        <img
          src={HERO_IMAGE}
          alt=""
          fetchpriority="high"
          className="h-full w-full object-cover"
        />
      </motion.div>
      <div
        className="absolute inset-0 bg-gradient-to-t from-[#231a15]/95 via-[#231a15]/45 to-[#231a15]/30"
        aria-hidden="true"
      />

      <div className="relative z-10 mx-auto w-full max-w-7xl px-4 pb-24 pt-40 sm:px-6 sm:pb-28 lg:px-12">
        <motion.p
          initial={reduce ? false : { opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.15, duration: 0.8 }}
          className="mb-6 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.3em] text-sand/90"
          data-testid="hero-location-badge"
        >
          <MapPin className="h-3.5 w-3.5" aria-hidden="true" />
          Xaló · Alicante
        </motion.p>

        <h1 className="font-display text-[17vw] font-medium leading-[0.95] tracking-tight text-cream sm:text-7xl lg:text-8xl">
          <span className="block overflow-hidden pb-1">
            <motion.span
              className="block"
              variants={lineVariants}
              initial={reduce ? false : "hidden"}
              animate="visible"
              custom={0}
            >
              La Bonica
            </motion.span>
          </span>
          <span className="block overflow-hidden pb-2">
            <motion.span
              className="block italic text-gold"
              variants={lineVariants}
              initial={reduce ? false : "hidden"}
              animate="visible"
              custom={1}
            >
              Café
            </motion.span>
          </span>
        </h1>

        <motion.p
          initial={reduce ? false : { opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.75, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="mt-6 max-w-xl text-base leading-relaxed text-sand/95 sm:text-lg"
        >
          {BUSINESS.tagline}
        </motion.p>

        <motion.div
          initial={reduce ? false : { opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="mt-10 flex flex-col gap-3 sm:flex-row sm:items-center sm:gap-4"
        >
          <a
            href="#carta"
            data-testid="hero-view-menu-button"
            className="inline-flex items-center justify-center rounded-full bg-cream px-8 py-4 text-base font-semibold text-ink transition-colors duration-300 hover:bg-gold hover:text-ink"
          >
            Ver nuestra carta
          </a>
          <a
            href={BUSINESS.maps.directions}
            target="_blank"
            rel="noopener noreferrer"
            data-testid="hero-directions-button"
            className="inline-flex items-center justify-center gap-2 rounded-full border border-cream/40 px-8 py-4 text-base font-semibold text-cream transition-colors duration-300 hover:border-cream hover:bg-cream/10"
          >
            <MapPin className="h-5 w-5" aria-hidden="true" />
            Cómo llegar
          </a>
        </motion.div>

        <motion.div
          initial={reduce ? false : { opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.15, duration: 0.9 }}
          className="mt-12 flex flex-wrap items-center gap-x-6 gap-y-3 text-sm text-sand/85"
        >
          <span className="inline-flex items-center gap-2" data-testid="hero-rating-badge">
            <Star className="h-4 w-4 fill-gold text-gold" aria-hidden="true" />
            {BUSINESS.rating.value}/{BUSINESS.rating.outOf} · {BUSINESS.rating.count} reseñas
          </span>
          <span className="hidden h-4 w-px bg-cream/25 sm:block" aria-hidden="true" />
          <span>Café · Dulces caseros · Club sándwich</span>
        </motion.div>
      </div>

      <motion.a
        href="#nosotros"
        aria-label="Bajar a la sección Nosotros"
        data-testid="hero-scroll-indicator"
        initial={reduce ? false : { opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
        className="absolute bottom-6 right-6 hidden h-12 w-12 items-center justify-center rounded-full border border-cream/30 text-cream/80 transition-colors hover:border-cream hover:text-cream md:flex"
      >
        <motion.span
          animate={reduce ? {} : { y: [0, 5, 0] }}
          transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
        >
          <ArrowDown className="h-5 w-5" aria-hidden="true" />
        </motion.span>
      </motion.a>
    </section>
  );
}
