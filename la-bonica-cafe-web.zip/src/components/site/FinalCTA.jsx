import { Phone, Navigation } from "lucide-react";
import { Reveal } from "./Reveal";
import { BUSINESS } from "../../data/business";

export default function FinalCTA() {
  return (
    <section className="relative overflow-hidden bg-coffee-dark text-cream">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-24 -top-24 h-96 w-96 rounded-full bg-gold/10 blur-3xl"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -bottom-32 -left-24 h-96 w-96 rounded-full bg-terracotta/15 blur-3xl"
      />
      <div className="relative mx-auto max-w-4xl px-4 py-24 text-center sm:px-6 sm:py-32 lg:py-40">
        <Reveal>
          <p className="text-[11px] font-semibold uppercase tracking-[0.3em] text-gold">Te esperamos</p>
        </Reveal>
        <Reveal delay={0.1}>
          <h2 className="mt-6 font-display text-4xl font-medium leading-[1.08] tracking-tight sm:text-5xl lg:text-6xl text-balance">
            Tu próximo café te espera en <span className="italic text-gold">Xaló</span>.
          </h2>
        </Reveal>
        <Reveal delay={0.2}>
          <p className="mx-auto mt-6 max-w-xl text-base leading-relaxed text-sand/85 sm:text-lg">
            Pásate por La Bonica Café, siéntate con calma y disfruta de un café y un dulce
            casero en buena compañía.
          </p>
        </Reveal>
        <Reveal delay={0.3}>
          <div className="mt-10 flex flex-col justify-center gap-3 sm:flex-row sm:gap-4">
            <a
              href={BUSINESS.maps.directions}
              target="_blank"
              rel="noopener noreferrer"
              data-testid="cta-directions-button"
              className="inline-flex items-center justify-center gap-2 rounded-full border border-cream/30 px-8 py-4 text-base font-semibold text-cream transition-colors duration-300 hover:border-cream hover:bg-cream/10"
            >
              <Navigation className="h-5 w-5" aria-hidden="true" />
              Cómo llegar
            </a>
            <a
              href={BUSINESS.phone.href}
              data-testid="cta-call-button"
              className="inline-flex items-center justify-center gap-2 rounded-full bg-gold px-8 py-4 text-base font-semibold text-ink transition-colors duration-300 hover:bg-cream"
            >
              <Phone className="h-5 w-5" aria-hidden="true" />
              Llamar ahora
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
