import { MapPin, Phone, Navigation, Clock } from "lucide-react";
import { Reveal, ChapterLabel } from "./Reveal";
import { BUSINESS } from "../../data/business";

export default function Location() {
  return (
    <section id="contacto" className="mx-auto max-w-7xl px-4 py-20 sm:px-6 sm:py-28 lg:px-12 lg:py-36">
      <Reveal>
        <ChapterLabel number="05" title="Contacto" />
      </Reveal>
      <Reveal delay={0.08}>
        <h2 className="mt-6 font-display text-3xl font-medium leading-tight tracking-tight text-ink sm:text-4xl lg:text-5xl text-balance">
          Ven a <span className="italic text-terracotta">visitarnos</span>
        </h2>
      </Reveal>

      <div className="mt-14 grid gap-10 lg:grid-cols-2 lg:gap-16">
        <div className="flex flex-col gap-6">
          <Reveal delay={0.12}>
            <div className="rounded-3xl border border-line/70 bg-white p-7 sm:p-9" data-testid="contact-info-card">
              <div className="flex items-start gap-4">
                <span className="inline-flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-sand text-coffee">
                  <MapPin className="h-5 w-5" aria-hidden="true" />
                </span>
                <div>
                  <h3 className="font-display text-xl font-medium text-ink">Dirección</h3>
                  <p className="mt-1.5 leading-relaxed text-ink-soft">
                    {BUSINESS.address.street}
                    <br />
                    {BUSINESS.address.postalCode} {BUSINESS.address.city}, {BUSINESS.address.region}, {BUSINESS.address.country}
                  </p>
                </div>
              </div>

              <div className="mt-7 flex items-start gap-4 border-t border-line/70 pt-7">
                <span className="inline-flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-sand text-coffee">
                  <Phone className="h-5 w-5" aria-hidden="true" />
                </span>
                <div>
                  <h3 className="font-display text-xl font-medium text-ink">Teléfono</h3>
                  <a
                    href={BUSINESS.phone.href}
                    data-testid="contact-phone-link"
                    className="mt-1.5 inline-block text-lg font-semibold text-coffee transition-colors hover:text-terracotta"
                  >
                    {BUSINESS.phone.display}
                  </a>
                </div>
              </div>

              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <a
                  href={BUSINESS.maps.directions}
                  target="_blank"
                  rel="noopener noreferrer"
                  data-testid="contact-directions-link"
                  className="inline-flex flex-1 items-center justify-center gap-2 rounded-full bg-ink px-7 py-4 text-sm font-semibold text-cream transition-colors duration-300 hover:bg-terracotta"
                >
                  <Navigation className="h-4 w-4" aria-hidden="true" />
                  Cómo llegar
                </a>
                <a
                  href={BUSINESS.phone.href}
                  data-testid="contact-call-button"
                  className="inline-flex flex-1 items-center justify-center gap-2 rounded-full border border-ink/20 px-7 py-4 text-sm font-semibold text-ink transition-colors duration-300 hover:border-terracotta hover:text-terracotta"
                >
                  <Phone className="h-4 w-4" aria-hidden="true" />
                  Llamar
                </a>
              </div>
            </div>
          </Reveal>

          <Reveal delay={0.2}>
            <div className="rounded-3xl border border-line/70 bg-cream-alt/80 p-7 sm:p-9" data-testid="hours-card">
              <div className="flex items-start gap-4">
                <span className="inline-flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-sand text-coffee">
                  <Clock className="h-5 w-5" aria-hidden="true" />
                </span>
                <div className="w-full">
                  <h3 className="font-display text-xl font-medium text-ink">Horario</h3>
                  {BUSINESS.hours.length > 0 ? (
                    <ul className="mt-3 space-y-2">
                      {BUSINESS.hours.map((h) => (
                        <li key={h.days} className="flex items-center justify-between gap-4 text-sm text-ink-soft">
                          <span>{h.days}</span>
                          <span className="font-semibold tabular-nums text-ink">{h.time}</span>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="mt-1.5 leading-relaxed text-ink-soft" data-testid="hours-placeholder-text">
                      {BUSINESS.hoursNote}
                    </p>
                  )}
                </div>
              </div>
            </div>
          </Reveal>
        </div>

        <Reveal delay={0.18} className="min-h-[380px]">
          <div className="h-full overflow-hidden rounded-3xl border border-line/70 shadow-[0_24px_60px_-30px_rgba(44,34,30,0.35)]">
            <iframe
              title="Mapa: La Bonica Café, Av. Sant Domènec 4, Xaló, Alicante"
              data-testid="google-maps-embed-frame"
              src={BUSINESS.maps.embed}
              loading="lazy"
              allowFullScreen
              referrerPolicy="no-referrer-when-downgrade"
              className="h-full min-h-[380px] w-full border-0 lg:min-h-[560px]"
            />
          </div>
        </Reveal>
      </div>
    </section>
  );
}
