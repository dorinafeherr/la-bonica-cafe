import { Phone, MapPin, Instagram, Facebook } from "lucide-react";
import { BUSINESS, NAV_LINKS } from "../../data/business";

function SocialLink({ icon: Icon, label, url, testid }) {
  if (!url) {
    return (
      <span
        data-testid={testid}
        title={`${label}: enlace pendiente de añadir`}
        aria-label={`${label} (enlace pendiente)`}
        className="inline-flex h-11 w-11 cursor-not-allowed items-center justify-center rounded-full border border-cream/15 text-sand/40"
      >
        <Icon className="h-5 w-5" aria-hidden="true" />
      </span>
    );
  }
  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      data-testid={testid}
      aria-label={label}
      className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-cream/25 text-cream transition-colors hover:border-gold hover:text-gold"
    >
      <Icon className="h-5 w-5" aria-hidden="true" />
    </a>
  );
}

function LegalLink({ label, url, testid }) {
  if (!url) {
    return (
      <span data-testid={testid} className="cursor-not-allowed text-sand/40" title="Enlace pendiente de añadir">
        {label}
      </span>
    );
  }
  return (
    <a href={url} data-testid={testid} className="transition-colors hover:text-gold">
      {label}
    </a>
  );
}

export default function Footer() {
  return (
    <footer className="bg-ink text-sand" data-testid="site-footer">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-12">
        <div className="grid gap-12 md:grid-cols-3">
          <div>
            <p className="font-display text-2xl font-medium text-cream">
              La Bonica <span className="italic text-gold">Café</span>
            </p>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-sand/70">
              Café, dulces caseros y momentos para disfrutar en Xaló.
            </p>
            <div className="mt-6 flex gap-3">
              <SocialLink icon={Instagram} label="Instagram" url={BUSINESS.social.instagram} testid="footer-instagram-link" />
              <SocialLink icon={Facebook} label="Facebook" url={BUSINESS.social.facebook} testid="footer-facebook-link" />
            </div>
          </div>

          <nav aria-label="Enlaces del pie de página">
            <h3 className="text-xs font-semibold uppercase tracking-[0.25em] text-sand/50">Explora</h3>
            <ul className="mt-5 space-y-3">
              {NAV_LINKS.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    data-testid={`footer-${link.testid}`}
                    className="text-sm text-sand/80 transition-colors hover:text-gold"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <div>
            <h3 className="text-xs font-semibold uppercase tracking-[0.25em] text-sand/50">Contacto</h3>
            <address className="mt-5 space-y-4 text-sm not-italic leading-relaxed text-sand/80">
              <p className="flex items-start gap-3">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-gold" aria-hidden="true" />
                <span>
                  {BUSINESS.address.street}
                  <br />
                  {BUSINESS.address.postalCode} {BUSINESS.address.city}, {BUSINESS.address.region}
                </span>
              </p>
              <p>
                <a
                  href={BUSINESS.phone.href}
                  data-testid="footer-phone-link"
                  className="flex items-center gap-3 transition-colors hover:text-gold"
                >
                  <Phone className="h-4 w-4 shrink-0 text-gold" aria-hidden="true" />
                  {BUSINESS.phone.display}
                </a>
              </p>
            </address>
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-cream/10 pt-8 text-xs text-sand/50 sm:flex-row">
          <p>© {new Date().getFullYear()} La Bonica Café · Xaló, Alicante</p>
          <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2">
            <LegalLink label="Política de privacidad" url={BUSINESS.legal.privacy} testid="footer-legal-privacy" />
            <LegalLink label="Aviso legal" url={BUSINESS.legal.terms} testid="footer-legal-terms" />
            <LegalLink label="Política de cookies" url={BUSINESS.legal.cookies} testid="footer-legal-cookies" />
          </div>
        </div>
      </div>
    </footer>
  );
}
