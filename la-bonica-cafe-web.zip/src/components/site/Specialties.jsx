import { ArrowRight } from "lucide-react";
import { Reveal, ChapterLabel } from "./Reveal";
import { SPECIALTIES } from "../../data/business";

export default function Specialties() {
  return (
    <section id="carta" className="bg-cream-alt/70">
      <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 sm:py-28 lg:px-12 lg:py-36">
        <Reveal>
          <ChapterLabel number="02" title="La carta" />
        </Reveal>
        <div className="mt-6 flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
          <Reveal delay={0.08}>
            <h2 className="font-display text-3xl font-medium leading-tight tracking-tight text-ink sm:text-4xl lg:text-5xl text-balance">
              Nuestros <span className="italic text-terracotta">favoritos</span>
            </h2>
          </Reveal>
          <Reveal delay={0.16}>
            <p className="max-w-md text-sm leading-relaxed text-muted sm:text-base">
              Lo que más destacan quienes nos visitan. La carta completa estará disponible
              aquí próximamente.
            </p>
          </Reveal>
        </div>

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3 lg:gap-8">
          {SPECIALTIES.map((item, i) => (
            <Reveal key={item.id} delay={0.1 * i}>
              <article
                data-testid={item.testid}
                className="group relative flex h-full flex-col overflow-hidden rounded-3xl border border-line/70 bg-white transition-shadow duration-500 hover:shadow-[0_24px_60px_-24px_rgba(44,34,30,0.35)]"
              >
                <div className="relative overflow-hidden">
                  <img
                    src={item.image}
                    alt={item.alt}
                    loading="lazy"
                    className="aspect-[4/3] w-full object-cover transition-transform duration-700 group-hover:scale-[1.05]"
                  />
                  <span className="absolute left-4 top-4 rounded-full bg-cream/95 px-3 py-1.5 text-[11px] font-semibold uppercase tracking-[0.18em] text-coffee">
                    {item.badge}
                  </span>
                </div>
                <div className="flex flex-1 flex-col p-6 sm:p-7">
                  <span className="font-display text-sm italic text-terracotta" aria-hidden="true">
                    {item.number}
                  </span>
                  <h3 className="mt-2 font-display text-2xl font-medium text-ink">{item.title}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-ink-soft sm:text-base">{item.text}</p>
                </div>
              </article>
            </Reveal>
          ))}
        </div>

        <Reveal delay={0.2} className="mt-12">
          <a
            href="#contacto"
            data-testid="open-full-menu-button"
            className="group inline-flex items-center gap-2 rounded-full border border-ink/20 px-7 py-3.5 text-sm font-semibold text-ink transition-colors duration-300 hover:border-terracotta hover:text-terracotta"
            aria-label="Ver la carta: la carta completa estará disponible próximamente, contacta para más información"
          >
            Ver la carta
            <span className="rounded-full bg-sand px-2.5 py-0.5 text-[11px] font-semibold uppercase tracking-wider text-coffee">
              Próximamente
            </span>
            <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" aria-hidden="true" />
          </a>
        </Reveal>
      </div>
    </section>
  );
}
