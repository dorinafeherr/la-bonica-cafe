// ============================================================
// DATOS CENTRALIZADOS DE LA BONICA CAFÉ
// Edita este archivo para actualizar teléfono, horarios,
// reseñas, enlaces sociales y fotografías.
// ============================================================

export const BUSINESS = {
  name: "La Bonica Café",
  category: "Cafetería",
  tagline: "Café, dulces caseros y momentos para disfrutar en Xaló.",
  priceRange: "10–20 € por persona",
  rating: { value: "4,7", outOf: "5", count: "4.739" },

  address: {
    street: "Av. Sant Domènec, 4",
    city: "Xaló (Jalón)",
    postalCode: "03727",
    region: "Alicante",
    country: "España",
    full: "Av. Sant Domènec, 4 · 03727 Xaló, Alicante",
  },

  phone: {
    display: "+34 633 02 43 70",
    href: "tel:+34633024370",
  },

  maps: {
    directions:
      "https://www.google.com/maps/dir/?api=1&destination=Av.+Sant+Dom%C3%A8nec+4,+03727+Xal%C3%B3,+Alicante,+Espa%C3%B1a",
    embed:
      "https://www.google.com/maps?q=Av.+Sant+Dom%C3%A8nec+4,+03727+Xal%C3%B3,+Alicante,+Espa%C3%B1a&output=embed",
    reviewsUrl:
      "https://www.google.com/maps/search/?api=1&query=La+Bonica+Caf%C3%A9,+Xal%C3%B3,+Alicante",
  },

  // Espacios preparados: añade las URLs cuando estén disponibles
  social: { instagram: null, facebook: null },
  legal: { privacy: null, terms: null, cookies: null },

  // Horarios: añade las franjas reales aquí. Ejemplo:
  // { days: "Lunes a Viernes", time: "08:00 – 20:00" },
  hours: [],
  hoursNote: "Consulta nuestros horarios antes de visitarnos.",
};

export const NAV_LINKS = [
  { label: "Inicio", href: "#inicio", testid: "nav-link-inicio" },
  { label: "Nosotros", href: "#nosotros", testid: "nav-link-nosotros" },
  { label: "Carta", href: "#carta", testid: "nav-link-carta" },
  { label: "Galería", href: "#galeria", testid: "nav-link-galeria" },
  { label: "Reseñas", href: "#resenas", testid: "nav-link-resenas" },
  { label: "Contacto", href: "#contacto", testid: "nav-link-contacto" },
];

export const SPECIALTIES = [
  {
    id: "cafe",
    number: "01",
    title: "Café",
    text: "Un café cuidado y lleno de aroma, una de las experiencias que los clientes destacan especialmente.",
    badge: "El más destacado",
    image:
      "https://images.unsplash.com/photo-1541167760496-1628856ab772?auto=format&fit=crop&w=900&q=80",
    alt: "Taza de café con latte art servida en mesa de madera",
    testid: "especialidades-card-cafe",
  },
  {
    id: "dulces",
    number: "02",
    title: "Dulces caseros",
    text: "Dulces y tartas caseras que han recibido excelentes comentarios de los clientes.",
    badge: "Hecho en casa",
    image:
      "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=900&q=80",
    alt: "Porción de tarta casera con capas de chocolate",
    testid: "especialidades-card-dulces",
  },
  {
    id: "sandwich",
    number: "03",
    title: "Club Sandwich",
    text: "Uno de los platos mencionados especialmente en las reseñas de nuestros clientes.",
    badge: "Favorito de las reseñas",
    image:
      "https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&w=900&q=80",
    alt: "Club sándwich cortado en triángulos sobre tabla de madera",
    testid: "especialidades-card-sandwich",
  },
];

// Reseñas reales proporcionadas por el negocio. No añadir nombres ni notas inventadas.
export const REVIEWS = [
  {
    quote: "Los dulces son una pasada, todo casero.",
    source: "Reseña de cliente",
  },
  {
    quote: "Club sándwich de los mejores que he probado.",
    source: "Reseña de cliente",
  },
  {
    quote:
      "Un café excelente, con toda su crema y aromas cítricos servidos en un vaso artesanal. Os recomiendo acompañarlo con un trozo de tarta casera. Me encanta 😍",
    source: "Reseña de cliente",
  },
];

// ============================================================
// FOTOGRAFÍAS — MARCADORES DE POSICIÓN
// Sustituye estas URLs por las fotografías reales de La Bonica
// Café manteniendo la misma estructura { src, alt, tall }.
// tall: true ocupa dos filas en el mosaico.
// ============================================================
export const GALLERY_IMAGES = [
  {
    src: "https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=1000&q=80",
    alt: "Interior acogedor de cafetería con luz cálida",
    tall: true,
  },
  {
    src: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=1000&q=80",
    alt: "Taza de café servida junto a la ventana",
    tall: false,
  },
  {
    src: "https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&w=1000&q=80",
    alt: "Croissants recién horneados",
    tall: false,
  },
  {
    src: "https://images.unsplash.com/photo-1442512595331-e89e73853f31?auto=format&fit=crop&w=1000&q=80",
    alt: "Barista preparando café de filtro de forma artesanal",
    tall: true,
  },
  {
    src: "https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=1000&q=80",
    alt: "Pan y bollería artesanal recién hecha",
    tall: false,
  },
  {
    src: "https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=1000&q=80",
    alt: "Café con leche servido en taza de cerámica",
    tall: false,
  },
  {
    src: "https://images.unsplash.com/photo-1521017432531-fbd92d768814?auto=format&fit=crop&w=1000&q=80",
    alt: "Fachada y terraza de una cafetería de barrio",
    tall: true,
  },
  {
    src: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=1000&q=80",
    alt: "Tarta casera de chocolate por capas",
    tall: false,
  },
  {
    src: "https://images.unsplash.com/photo-1447933601403-0c6688de566e?auto=format&fit=crop&w=1000&q=80",
    alt: "Granos de café tostado",
    tall: false,
  },
  {
    src: "https://images.unsplash.com/photo-1559925393-8be0ec4767c8?auto=format&fit=crop&w=1000&q=80",
    alt: "Barra de cafetería con obrador a la vista",
    tall: true,
  },
  {
    src: "https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&w=1000&q=80",
    alt: "Club sándwich servido en tabla de madera",
    tall: false,
  },
  {
    src: "https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=1000&q=80",
    alt: "Momento de café y dulce en buena compañía",
    tall: false,
  },
];

export const HERO_IMAGE =
  "https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=2000&q=80";

export const ABOUT_IMAGE =
  "https://images.unsplash.com/photo-1442512595331-e89e73853f31?auto=format&fit=crop&w=1000&q=80";
