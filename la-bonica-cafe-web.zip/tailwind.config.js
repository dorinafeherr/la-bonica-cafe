/** @type {import('tailwindcss').Config} */
module.exports = {
    blocklist: ["overline"],
    darkMode: ["class"],
    content: ["./src/**/*.{js,jsx,ts,tsx}", "./public/index.html"],
    theme: {
        extend: {
            fontFamily: {
                sans: ['"Plus Jakarta Sans"', "ui-sans-serif", "system-ui", "sans-serif"],
                display: ["Fraunces", "Georgia", "serif"],
            },
            colors: {
                cream: "#FDFBF7",
                "cream-alt": "#F5EFE6",
                sand: "#EFE6D8",
                ink: "#2C221E",
                "ink-soft": "#594A42",
                coffee: {
                    DEFAULT: "#6F4E37",
                    dark: "#543A28",
                },
                terracotta: "#C86D51",
                gold: "#D4A359",
                olive: "#6E7A55",
                line: "#E8DEC9",
                background: "hsl(var(--background))",
                foreground: "hsl(var(--foreground))",
                border: "hsl(var(--border))",
                input: "hsl(var(--input))",
                ring: "hsl(var(--ring))",
            },
            keyframes: {
                "accordion-down": {
                    from: { height: "0" },
                    to: { height: "var(--radix-accordion-content-height)" },
                },
                "accordion-up": {
                    from: { height: "var(--radix-accordion-content-height)" },
                    to: { height: "0" },
                },
            },
            animation: {
                "accordion-down": "accordion-down 0.2s ease-out",
                "accordion-up": "accordion-up 0.2s ease-out",
            },
        },
    },
    plugins: [require("tailwindcss-animate")],
};
